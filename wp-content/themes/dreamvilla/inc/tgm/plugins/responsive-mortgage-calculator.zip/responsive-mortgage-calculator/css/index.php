<?php
// Enjoy the silence.
?>